Spring REST API & Security
