package com.ndmm.cms.domain.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ndmm.cms.domain.model.QnA;
import com.ndmm.cms.domain.model.QnADTO;
import com.ndmm.cms.domain.repository.QnARepository;

import jakarta.inject.Inject;

@Service
@Transactional
public class QnAServiceImpl implements QnAService {

	
	@Inject
	QnARepository qnaRepository;

	@Override
	public List<QnADTO> qaGetAll() {

		return qnaRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
	}

	@Override
	public QnA qaFindOne(Integer qaId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public QnA qaCreate(QnA qa) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public QnA qaUpdate(Integer qaId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void qaDelete(Integer qaId) {
		// TODO Auto-generated method stub
		
	}
	
    // Convert Product Entity to ProductDTO
    private QnADTO convertToDTO(QnA qna) {
        return new QnADTO(qna.getId(), qna.getQuestion(), qna.getAnswer());
    }

    // Convert ProductDTO to Product Entity
    private QnA convertToEntity(QnADTO qnaDTO) {
    	QnA qna = new QnA();
    	qna.setQuestion(qnaDTO.question());
    	qna.setAnswer(qnaDTO.answer());
        return qna;
    }

	
	
}
