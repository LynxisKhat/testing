package com.ndmm.cms.domain.service;

import com.ndmm.cms.domain.model.AboutUs;
import com.ndmm.cms.domain.model.AboutUsDTO;
import java.util.List;

public interface AboutUsService {
    List<AboutUsDTO> getAllAboutUs();
    
    AboutUs aboutusFindOne(Long aboutusId);
    
    AboutUs aboutusCreate(AboutUsDTO aboutusDTO);
    
    AboutUs aboutusUpdate(Long aboutusId, AboutUsDTO aboutusDTO);
    
    void aboutusDelete(Long aboutusId);
}
