package com.ndmm.cms.domain.model;

public record QnADTO(Long id,String question,String answer) {}
