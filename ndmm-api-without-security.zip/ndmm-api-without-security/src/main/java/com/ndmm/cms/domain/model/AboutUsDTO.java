package com.ndmm.cms.domain.model;

public record AboutUsDTO(Long id, String header, String description) {}
