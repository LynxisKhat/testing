package com.ndmm.cms.domain.service;

import com.ndmm.cms.domain.model.AboutUs;
import com.ndmm.cms.domain.model.AboutUsDTO;
import com.ndmm.cms.domain.repository.AboutUsRepository;
import jakarta.inject.Inject;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class AboutUsServiceImpl implements AboutUsService {

    @Inject
    private AboutUsRepository aboutUsRepository;

//    @Override
//    public List<AboutUsDTO> getAllAboutUs() {
//        return aboutUsRepository.findAll().stream()
//                .map(this::convertToDTO)
//                .collect(Collectors.toList());
//    }
    
    @Override
    public List<AboutUsDTO> getAllAboutUs() {
        List<AboutUs> aboutUsList = aboutUsRepository.findAll();
        return aboutUsList.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }


    @Override
    public AboutUs aboutusFindOne(Long aboutusId) {
        Optional<AboutUs> aboutUs = aboutUsRepository.findById(aboutusId);
        return aboutUs.orElse(null);
    }

    @Override
    public AboutUs aboutusCreate(AboutUsDTO aboutUsDTO) {
    	AboutUs aboutus = convertToEntity(aboutUsDTO);
        return aboutUsRepository.save(aboutus);
    }

    @Override
    public AboutUs aboutusUpdate(Long aboutusId, AboutUsDTO aboutUsDTO) {
        if (aboutUsRepository.existsById(aboutusId)) {
        	AboutUs aboutUs = convertToEntity(aboutUsDTO);
            aboutUs.setId(aboutusId);
            return aboutUsRepository.save(aboutUs);
        }
        return null;
    }

    @Override
    public void aboutusDelete(Long aboutusId) {
        aboutUsRepository.deleteById(aboutusId);
    }

    private AboutUsDTO convertToDTO(AboutUs aboutUs) {
        return new AboutUsDTO(aboutUs.getId(), aboutUs.getHeader(), aboutUs.getDescription());
    }

    private AboutUs convertToEntity(AboutUsDTO aboutUsDTO) {
        AboutUs aboutUs = new AboutUs();
        aboutUs.setHeader(aboutUsDTO.header());
        aboutUs.setDescription(aboutUsDTO.description());
        return aboutUs;
    }
}
