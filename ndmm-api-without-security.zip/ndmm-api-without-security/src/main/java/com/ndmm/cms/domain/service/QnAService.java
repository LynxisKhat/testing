package com.ndmm.cms.domain.service;

import java.util.List;

import com.ndmm.cms.domain.model.QnA;
import com.ndmm.cms.domain.model.QnADTO;

public interface QnAService {
	
	List<QnADTO> qaGetAll();
	
	QnA qaFindOne(Integer qaId);
	
	QnA qaCreate(QnA qa);
	
	QnA qaUpdate(Integer qaId);
	
	void qaDelete(Integer qaId);
}
