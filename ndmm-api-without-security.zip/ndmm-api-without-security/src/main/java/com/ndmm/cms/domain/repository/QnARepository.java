package com.ndmm.cms.domain.repository;

import com.ndmm.cms.domain.model.QnA;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QnARepository extends JpaRepository<QnA, Long> {
}