package com.ndmm.cms.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ndmm.cms.domain.model.AboutUs;

public interface AboutUsRepository extends JpaRepository<AboutUs, Long> {

}
