package com.ndmm.cms.config.app;

import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

/**
 * Bean definitions for infrastructure layer.
 */
@Configuration
@EnableJpaRepositories("com.ndmm.cms.domain.repository")
@Import({CmsEnvConfig.class})
public class CmsInfraConfig {

    /**
     * Database property.
     */
    @Value("${database}")
    private Database database;

    /**
     * Configure {@link HibernateJpaVendorAdapter} bean.
     * @return Bean of configured {@link HibernateJpaVendorAdapter}
     */
    @Bean("jpaVendorAdapter")
    public HibernateJpaVendorAdapter jpaVendorAdapter() {
        HibernateJpaVendorAdapter bean = new HibernateJpaVendorAdapter();
        bean.setDatabase(database);
        return bean;
    }

    /**
     * Configure {@link LocalContainerEntityManagerFactoryBean} bean.
     * @param dataSource DataSource
     * @return Bean of configured {@link LocalContainerEntityManagerFactoryBean}
     */
    @Bean("entityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource) {
        LocalContainerEntityManagerFactoryBean bean = new LocalContainerEntityManagerFactoryBean();
        bean.setPackagesToScan("com.ndmm.cms.domain.model");
        bean.setDataSource(dataSource);
        bean.setJpaVendorAdapter(jpaVendorAdapter());
        bean.setJpaPropertyMap(jpaPropertyMap());
        return bean;
    }

    /**
     * Configure {@link LocalContainerEntityManagerFactoryBean}.JpaPropertyMap.
     * @return configured JpaPropertyMap
     */
    private Map<String, ?> jpaPropertyMap() {
        Map<String, Object> jpaPropertyMap = new HashMap<>();
        jpaPropertyMap.put("hibernate.connection.charSet", "UTF-8");
        jpaPropertyMap.put("hibernate.format_sql", false);
        jpaPropertyMap.put("hibernate.use_sql_comments", true);
        jpaPropertyMap.put("hibernate.jdbc.batch_size", 30);
        jpaPropertyMap.put("hibernate.jdbc.fetch_size", 100);
        return jpaPropertyMap;
    }
}
