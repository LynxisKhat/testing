package com.ndmm.cms.api.cms;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ndmm.cms.domain.model.AboutUs;
import com.ndmm.cms.domain.model.AboutUsDTO;
import com.ndmm.cms.domain.model.QnADTO;
import com.ndmm.cms.domain.service.AboutUsService;
import com.ndmm.cms.domain.service.QnAService;

import jakarta.inject.Inject;

@RestController
@RequestMapping("client")
public class ClientController {
    
    @Inject
    QnAService qnAService;

    @GetMapping("/qas")
    public List<QnADTO> getQAs() {
        List<QnADTO> qas = qnAService.qaGetAll();
        return qas;
    }
    
    @Inject
    AboutUsService aboutUsService;
    
    @GetMapping("/aboutus")
    public List<AboutUsDTO> getAboutUs() {
    	return aboutUsService.getAllAboutUs();
    }
    
    //Yazar Testing
    @PostMapping("/aboutus")
    public AboutUsDTO createAboutUs(@RequestBody AboutUsDTO aboutUsDTO) {
    	System.out.println(aboutUsDTO);
    	AboutUs aboutUs = aboutUsService.aboutusCreate(aboutUsDTO);
    	return new AboutUsDTO(aboutUs.getId(), aboutUs.getHeader(), aboutUs.getDescription());
    }
    //Testing End
}
