package com.ndmm.cms.config.web;

import static org.springframework.security.web.util.matcher.AntPathRequestMatcher.antMatcher;

import java.util.LinkedHashMap;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;
import org.springframework.security.web.access.DelegatingAccessDeniedHandler;
import org.springframework.security.web.access.expression.DefaultWebSecurityExpressionHandler;
import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
import org.springframework.security.web.csrf.InvalidCsrfTokenException;
import org.springframework.security.web.csrf.MissingCsrfTokenException;
import org.springframework.web.servlet.handler.HandlerMappingIntrospector;
import org.terasoluna.gfw.security.web.logging.UserIdMDCPutFilter;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
@EnableWebSecurity
public class SpringSecurityConfig {

    /** CORS configuration for Next.js frontend */
    @Bean
    public CorsFilter corsFilter() {
        CorsConfiguration config = new CorsConfiguration();
        config.addAllowedOrigin("http://localhost:3000");
        config.setAllowCredentials(true);
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return new CorsFilter(source);
    }

    /** Required bean for MvcRequestMatcher */
    @Bean
    public HandlerMappingIntrospector mvcHandlerMappingIntrospector() {
        return new HandlerMappingIntrospector();
    }

    /** Skip security for static resources */
    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return web -> web.ignoring().requestMatchers(antMatcher("/resources/**"));
    }

    /** Security filter chain */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .cors(Customizer.withDefaults())
            .csrf(csrf -> csrf.disable()) // disable for session login from JS frontend
            .formLogin(form -> form
        	    .loginProcessingUrl("/login")
        	    .successHandler((request, response, authentication) -> {
        	        response.setStatus(HttpServletResponse.SC_OK);
        	        response.setContentType("application/json");
        	        response.getWriter().write("{\"message\": \"Login successful\"}");
        	    })
        	    .failureHandler((request, response, exception) -> {
        	        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        	        response.setContentType("application/json");
        	        response.getWriter().write("{\"error\": \"Invalid credentials\"}");
        	    })
        	    .permitAll()
        	 )   
            .logout(logout -> logout
                .logoutUrl("/logout")
                .logoutSuccessUrl("/login?logout")
            )
            .exceptionHandling(ex -> ex.accessDeniedHandler(accessDeniedHandler()))
            .sessionManagement(Customizer.withDefaults())
            .addFilterAfter(userIdMDCPutFilter(), AnonymousAuthenticationFilter.class)
            .authorizeHttpRequests(authz -> authz
                .requestMatchers(antMatcher("/api/client/**")).permitAll()
                .requestMatchers(antMatcher("/api/admin/**")).hasRole("ADMIN")
                .anyRequest().authenticated()
            );

        return http.build();
    }

    /** AccessDeniedHandler with CSRF-specific error pages */
    @Bean("accessDeniedHandler")
    public AccessDeniedHandler accessDeniedHandler() {
        LinkedHashMap<Class<? extends AccessDeniedException>, AccessDeniedHandler> errorHandlers = new LinkedHashMap<>();

        AccessDeniedHandlerImpl invalidCsrfHandler = new AccessDeniedHandlerImpl();
        invalidCsrfHandler.setErrorPage("/WEB-INF/views/common/error/invalidCsrfTokenError.jsp");
        errorHandlers.put(InvalidCsrfTokenException.class, invalidCsrfHandler);

        AccessDeniedHandlerImpl missingCsrfHandler = new AccessDeniedHandlerImpl();
        missingCsrfHandler.setErrorPage("/WEB-INF/views/common/error/missingCsrfTokenError.jsp");
        errorHandlers.put(MissingCsrfTokenException.class, missingCsrfHandler);

        AccessDeniedHandlerImpl defaultHandler = new AccessDeniedHandlerImpl();
        defaultHandler.setErrorPage("/WEB-INF/views/common/error/accessDeniedError.jsp");

        return new DelegatingAccessDeniedHandler(errorHandlers, defaultHandler);
    }

    @Bean("webSecurityExpressionHandler")
    public DefaultWebSecurityExpressionHandler webSecurityExpressionHandler() {
        return new DefaultWebSecurityExpressionHandler();
    }

    @Bean("userIdMDCPutFilter")
    public UserIdMDCPutFilter userIdMDCPutFilter() {
        return new UserIdMDCPutFilter();
    }
    
    @Bean
    public UserDetailsService userDetailsService() {
        return new InMemoryUserDetailsManager(
            User.withUsername("admin")
                .password("{noop}adminpass") // Use {noop} for plaintext, or bcrypt in prod
                .roles("ADMIN")
                .build(),
            User.withUsername("client")
                .password("{noop}clientpass")
                .roles("CLIENT")
                .build()
        );
    }
}
