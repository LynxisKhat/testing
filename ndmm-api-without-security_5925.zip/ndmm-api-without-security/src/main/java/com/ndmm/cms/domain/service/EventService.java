package com.ndmm.cms.domain.service;

import java.util.List;

import com.ndmm.cms.domain.model.Event;
import com.ndmm.cms.domain.model.EventDTO;

public  interface EventService {
	
	 List<EventDTO> GetAll_event();
	 Event event_Create(Event event);
	 Event event_UPdate(Integer event_id);
	 void event_Delete(Integer event_id);
	 Event event_Edit(Integer event_id);
	 

}
