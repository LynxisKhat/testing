package com.ndmm.cms.domain.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ndmm.cms.domain.model.SecurityCompliance;
import com.ndmm.cms.domain.repository.AboutUsRepository;
import com.ndmm.cms.domain.repository.SecurityComplianceRepository;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@Service
@Transactional

public class SecurityComplianceServiceImpl implements SecurityComplianceService {

	@Inject
	SecurityComplianceRepository securityComplianceRepository;

	@Override
	public ResponseEntity<List<SecurityCompliance>> getAllSecurityCompliance(){
		List<SecurityCompliance> securityComplianceList = securityComplianceRepository.findAll();
		return ResponseEntity.ok(securityComplianceList);
	}
	
	@Override
	public ResponseEntity<SecurityCompliance> updateSecurityCompliance(SecurityCompliance securityCompliance){
		LocalDateTime currentDate = LocalDateTime.now();
		securityCompliance.setUpdated_At(currentDate);
		
		if(securityCompliance.getId() == null || !securityComplianceRepository.existsById(securityCompliance.getId())) {
			return ResponseEntity.notFound().build();
		}
		SecurityCompliance updatedSecurityCompliance = securityComplianceRepository.save(securityCompliance);
		return ResponseEntity.ok(updatedSecurityCompliance);
	}
	
}
