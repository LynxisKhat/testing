package com.ndmm.cms.domain.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.ndmm.cms.domain.model.Contact;

import com.ndmm.cms.domain.repository.ContactRepository;



import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class ContactServiceImpl implements ContactService {
    
    @Inject
     ContactRepository contactRepository;

	@Override
	
    public List<Contact> getAllContacts() {
        return contactRepository.findAll();
    }

	@Override
	public Contact contact_Update(Integer contact_id) {
		// TODO Auto-generated method stub
		return null;
	}

	

   
    
}
