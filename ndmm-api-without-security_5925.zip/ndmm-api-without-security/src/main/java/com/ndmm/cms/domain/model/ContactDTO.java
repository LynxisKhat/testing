package com.ndmm.cms.domain.model;

public record ContactDTO(Long id, String phone_sales, String email_sales, String phone_general, String email_HR) {

}
