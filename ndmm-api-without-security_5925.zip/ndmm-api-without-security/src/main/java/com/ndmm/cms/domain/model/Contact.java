package com.ndmm.cms.domain.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table (name = "contact_details")
public class Contact {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	 @Column(name = "phone_sales")
	private String phone_sales;
	 
	 @Column(name = "email_sales")
	private String email_sales;
	 
	 @Column(name = "phone_general")
	private String phone_general;
	 
	 @Column(name = "email_hr")
	private String email_hr;
	
	 public Contact() {
	    }
	 
	public Contact(Long id, String phone_sales, String email_sales, String phone_general, String email_hr) {
		super();
		this.id = id;
		this.phone_sales = phone_sales;
		this.email_sales = email_sales;
		this.phone_general = phone_general;
		this.email_hr = email_hr;
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPhone_sales() {
		return phone_sales;
	}
	public void setPhone_sales(String phone_sales) {
		this.phone_sales = phone_sales;
	}
	public String getEmail_sales() {
		return email_sales;
	}
	public void setEmail_sales(String email_sales) {
		this.email_sales = email_sales;
	}
	public String getPhone_general() {
		return phone_general;
	}
	public void setPhone_general(String phone_general) {
		this.phone_general = phone_general;
	}
	public String getemail_hr() {
		return email_hr;
	}
	public void setemail_hr(String email_hr) {
		this.email_hr = email_hr;
	}

}
