package com.ndmm.cms.domain.service;

import com.ndmm.cms.domain.model.AboutUs;
import java.util.List;

import org.springframework.http.ResponseEntity;

public interface AboutUsService {
    ResponseEntity<List<AboutUs>> getAllAboutUs();
    
    ResponseEntity<AboutUs> updateAboutUs(AboutUs aboutUs);
}
