package com.ndmm.cms.domain.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.ndmm.cms.domain.model.Careers;
import com.ndmm.cms.domain.repository.CareersRepository;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class CareersServiceImpl implements CareersService {
	@Inject
	CareersRepository careersRepository;
	
	@Override
	public ResponseEntity<List<Careers>> getAllCareers(){
		List<Careers> careersList = careersRepository.findAll();
		return ResponseEntity.ok(careersList);
	}
}
