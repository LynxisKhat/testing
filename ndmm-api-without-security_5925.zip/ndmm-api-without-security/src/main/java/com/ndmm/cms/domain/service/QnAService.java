package com.ndmm.cms.domain.service;

import java.util.List;
import java.util.Optional;

import com.ndmm.cms.domain.model.QnA;

public interface QnAService {
	
	List<QnA> qaGetAll();
	
	Optional<QnA> qaFindOne(Long qaId);
	
	QnA qaCreate(QnA qa);
	
	void qaDeleteById(Long qaId);
}
