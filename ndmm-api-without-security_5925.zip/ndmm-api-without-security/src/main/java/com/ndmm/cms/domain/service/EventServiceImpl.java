package com.ndmm.cms.domain.service;

import java.util.List;


import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ndmm.cms.domain.model.Event;
import com.ndmm.cms.domain.model.EventDTO;
import com.ndmm.cms.domain.repository.EventRepository;

import jakarta.inject.Inject;


@Service
@Transactional
public class EventServiceImpl implements EventService {
	
	@Inject
	EventRepository eventRepository;

	@Override
	public List<EventDTO> GetAll_event() {
		return eventRepository.findAll().stream().map(this::convertToDTO).collect(Collectors.toList());
		
	}

	@Override
	public Event event_Create(Event event) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Event event_UPdate(Integer event_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void event_Delete(Integer event_id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Event event_Edit(Integer event_id) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private EventDTO convertToDTO(Event event) {
		return new EventDTO(
				event.getId(), 
				event.getTitle(), 
				event.getDate(), 
				event.getDescription(), 
				event.getImage());
	}
	
	private Event convertToEntity(EventDTO eventDTO) {
        return new Event(
            eventDTO.id(),
            eventDTO.title(),
            eventDTO.describtion(),
            eventDTO.images(),
            eventDTO.date()
        );
    }
	
	

}
