package com.ndmm.cms.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ndmm.cms.domain.model.Careers;

public interface CareersRepository extends JpaRepository<Careers, Long> {

}
