package com.ndmm.cms.domain.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ndmm.cms.domain.model.Contact;

public interface  ContactRepository extends JpaRepository<Contact, Long>{

}
