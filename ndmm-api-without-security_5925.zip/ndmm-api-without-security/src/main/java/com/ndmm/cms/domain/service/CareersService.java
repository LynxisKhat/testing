package com.ndmm.cms.domain.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.ndmm.cms.domain.model.Careers;

public interface CareersService {
	ResponseEntity<List<Careers>> getAllCareers();
}
