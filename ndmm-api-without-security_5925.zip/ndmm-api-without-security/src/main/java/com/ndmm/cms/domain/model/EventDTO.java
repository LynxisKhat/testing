package com.ndmm.cms.domain.model;

import java.sql.Date;

public record EventDTO (Long id, String title, Date date, String describtion, String images) {

}
