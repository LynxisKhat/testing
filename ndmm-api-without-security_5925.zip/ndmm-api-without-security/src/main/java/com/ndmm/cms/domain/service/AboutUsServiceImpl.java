package com.ndmm.cms.domain.service;

import com.ndmm.cms.domain.model.AboutUs;
import com.ndmm.cms.domain.repository.AboutUsRepository;
import jakarta.inject.Inject;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class AboutUsServiceImpl implements AboutUsService {

    @Inject
    private AboutUsRepository aboutUsRepository;
    
    @Override
    public ResponseEntity<List<AboutUs>> getAllAboutUs() {
        List<AboutUs> aboutUsList = aboutUsRepository.findAll();
        return ResponseEntity.ok(aboutUsList);
    }

    @Override
    public ResponseEntity<AboutUs> updateAboutUs(AboutUs aboutUs){
    	LocalDateTime currentDate = LocalDateTime.now();
    	aboutUs.setUpdatedAt(currentDate);
    	if (aboutUs.getId()==null || !aboutUsRepository.existsById(aboutUs.getId())) {
    		return ResponseEntity.notFound().build();
    	}
    	AboutUs updatedAboutUs = aboutUsRepository.save(aboutUs);
    	return ResponseEntity.ok(updatedAboutUs);
    }
}
