package com.ndmm.cms.domain.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ndmm.cms.domain.model.QnA;
import com.ndmm.cms.domain.repository.QnARepository;

import jakarta.inject.Inject;

@Service
@Transactional
public class QnAServiceImpl implements QnAService {

	
	@Inject
	QnARepository qnaRepository;

	@Override
	public List<QnA> qaGetAll() {
		return qnaRepository.findAll();
	}

	@Override
	public Optional<QnA> qaFindOne(Long qaId) {
		return qnaRepository.findById(qaId);
	}

	@Override
	public QnA qaCreate(QnA qa) {
		return qnaRepository.save(qa);
	}

	@Override
	public void qaDeleteById(Long qaId) {
		qnaRepository.deleteById(qaId);
	}
	
}
