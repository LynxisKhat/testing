package com.ndmm.cms.domain.service;

import java.util.List;



import com.ndmm.cms.domain.model.Contact;


public interface ContactService {
    List<Contact> getAllContacts();
    Contact contact_Update(Integer contact_id);
}
