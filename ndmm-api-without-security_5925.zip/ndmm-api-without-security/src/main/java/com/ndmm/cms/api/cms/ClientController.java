package com.ndmm.cms.api.cms;

import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ndmm.cms.domain.model.AboutUs;
import com.ndmm.cms.domain.model.Careers;
import com.ndmm.cms.domain.model.QnA;
import com.ndmm.cms.domain.model.SecurityCompliance;
import com.ndmm.cms.domain.service.AboutUsService;
import com.ndmm.cms.domain.service.CareersService;
import com.ndmm.cms.domain.service.QnAService;
import com.ndmm.cms.domain.service.SecurityComplianceService;

import jakarta.inject.Inject;

@RestController
@RequestMapping("client")
public class ClientController {
    
    @Inject
    QnAService qnAService;
    
    @Inject
    AboutUsService aboutUsService;
    
    @Inject
    CareersService careersService;
    
    @Inject
    SecurityComplianceService securityComplianceService;
    
    @GetMapping("/qas")
    public ResponseEntity<List<QnA>> getQAs() {
        List<QnA> qas = qnAService.qaGetAll();
        return new ResponseEntity<>(qas, HttpStatus.OK);
    }
    
    @GetMapping("/qas/{id}")
    public ResponseEntity<QnA> getQAById(@PathVariable("id") long id) {
    	Optional<QnA> qa = qnAService.qaFindOne(id);
         return new ResponseEntity<>(qa.get(), HttpStatus.OK);
    }
    
    @PostMapping("/qas")
    public ResponseEntity<QnA> createQnA(@RequestBody QnA qna) {
      try {
        QnA _qna = qnAService.qaCreate(new QnA(qna.getQuestion(),qna.getAnswer()));
        return new ResponseEntity<>(_qna, HttpStatus.CREATED);
      } catch (Exception e) {
        return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
      }
    }
    
    @PutMapping("/qas/{id}")
    public ResponseEntity<QnA> updateQnA(@PathVariable("id") long id, @RequestBody QnA qna) {
    	Optional<QnA> qa = qnAService.qaFindOne(id);
      if (qa.isPresent()) {
        QnA _qa = qa.get();
        _qa.setQuestion(qna.getQuestion());
        _qa.setAnswer(qna.getAnswer());
        return new ResponseEntity<>(qnAService.qaCreate(_qa), HttpStatus.OK);
      } else {
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
      }
    }
    
    @DeleteMapping("/qas/{id}")
    public ResponseEntity<HttpStatus> deleteTutorial(@PathVariable("id") long id) {
      try {
    	  qnAService.qaDeleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
      } catch (Exception e) {
        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
      }
    }

    @GetMapping("/aboutus")
    public ResponseEntity<List<AboutUs>> getAboutUs() {
    	return aboutUsService.getAllAboutUs();
    }
       
    @PutMapping("/aboutus")
    ResponseEntity<AboutUs> UpdateAboutUs(@RequestBody AboutUs aboutUs){
    	return aboutUsService.updateAboutUs(aboutUs);
    }
    
    @GetMapping("/security-compliance")
    public ResponseEntity<List<SecurityCompliance>> getSecurityCompliance(){
    	return securityComplianceService.getAllSecurityCompliance();
    }
    
    @PutMapping("/security-compliance")
    ResponseEntity<SecurityCompliance> UpdateSecurityCompliance(@RequestBody SecurityCompliance securityCompliance){
    	return securityComplianceService.updateSecurityCompliance(securityCompliance);
    }
    
    @GetMapping("/careers")
    public ResponseEntity<List<Careers>> getCareers(){
    	return careersService.getAllCareers();
    }
    
}

