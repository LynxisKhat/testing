package com.ndmm.cms.domain.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.ndmm.cms.domain.model.SecurityCompliance;

public interface SecurityComplianceService {
	ResponseEntity<List<SecurityCompliance>> getAllSecurityCompliance();
	
	ResponseEntity<SecurityCompliance> updateSecurityCompliance(SecurityCompliance securityCompliance);
	
}
